from hello.utils import greet
print(greet("Example"))
