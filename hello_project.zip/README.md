# Hello

A simple Python CLI demo.

## Run
```bash
python -m src.hello.main
```
