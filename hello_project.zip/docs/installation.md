# Installation

Install Python 3.10+.
